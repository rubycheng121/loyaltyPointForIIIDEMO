package stepdefs;

import static org.junit.Assert.assertEquals;

import contract.Account;
import contract.Exchange;
import contract.LoyaltyPoint;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ExchangeSteps {

	private Exchange exchange;
	private Account myAccount;
	private Account partnerAccount;

	@Given("^the exchange rate is (\\d+\\.?\\d*)alp=(\\d+\\.?\\d*)blp$")
	public void the_exchange_rate_is_alp_blp(double alp, double blp) throws Throwable {
		myAccount = new Account("Company A");
		partnerAccount = new Account("Company B");
		exchange = new Exchange(myAccount, partnerAccount);
		myAccount.addLoyaltyPoint("Company B", new LoyaltyPoint("Company B", 0, blp / alp));
		partnerAccount.addLoyaltyPoint("Company A", new LoyaltyPoint("Company A", 0, alp / blp));
	}

	@Given("^original alp account of A is (\\d+)$")
	public void original_alp_account_of_A_is(long originalAlp) throws Throwable {
		myAccount.getLocalLoyaltyPoint().setPoints(originalAlp);
	}

	@Given("^original blp account of A is (\\d+)$")
	public void original_blp_account_of_A_is(long originalBlp) throws Throwable {
		myAccount.getLoyaltyPoint("Company B").setPoints(originalBlp);
	}

	@Given("^original alp account of B is (\\d+)$")
	public void original_alp_account_of_B_is(int originalAlp) throws Throwable {
		partnerAccount.getLoyaltyPoint("Company A").setPoints(originalAlp);
	}

	@Given("^original blp account of B is (\\d+)$")
	public void original_blp_account_of_B_is(int originalBlp) throws Throwable {
		partnerAccount.getLocalLoyaltyPoint().setPoints(originalBlp);
	}

	@When("^A want to exchange (\\d+) alp for blp$")
	public void a_want_to_exchange_alp_for_blp(long exchangingAlp) throws Throwable {
		exchange.to("Company B", exchangingAlp);
	}

	@Then("^alp account of A should be (\\d+)$")
	public void alp_account_of_A_should_be(long resultAlp) throws Throwable {
		assertEquals(resultAlp, exchange.getAccount().getLocalLoyaltyPoint().getPoints());
	}

	@Then("^blp account of A should be (\\d+)$")
	public void blp_account_of_A_should_be(long resultBlp) throws Throwable {
		assertEquals(resultBlp, exchange.getAccount().getLoyaltyPoint("Company B").getPoints());
	}

	@Then("^alp account of B should be (\\d+)$")
	public void alp_account_of_B_should_be(int resultBlp) throws Throwable {
		assertEquals(resultBlp, exchange.getPartnerAccount().getLoyaltyPoint("Company A").getPoints());
	}

	@Then("^blp account of B should be (\\d+)$")
	public void blp_account_of_B_should_be(int resultAlp) throws Throwable {
		assertEquals(resultAlp, exchange.getPartnerAccount().getLocalLoyaltyPoint().getPoints());
	}

}
