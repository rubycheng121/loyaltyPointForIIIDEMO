package contract;

@SmartContract
public class Exchange {

	private Account myAccount; // Company A; A wants to exchange 100 points for
								// B's points
	private Account partnerAccount; // Company B

	public Exchange(Account me, Account partner) {
		this.myAccount = me;
		this.partnerAccount = partner;
	}

	public boolean to(String targetName, long amount) {

		LoyaltyPoint target = myAccount.getLoyaltyPoint(targetName);
		LoyaltyPoint source = myAccount.getLocalLoyaltyPoint();
		LoyaltyPoint partnerSource = partnerAccount.getLoyaltyPoint(myAccount.getCompanyName());
		LoyaltyPoint partnerTarget = partnerAccount.getLocalLoyaltyPoint();

		if (source.getPoints() - amount < 0) {
			return false;
		}

		// A to B
		source.addPoints(0 - amount);
		partnerSource.addPoints(amount);
		System.out.println("==>"+partnerSource.getPoints());
		// B to A
		target.addPoints(Math.round(amount * target.getRate()));
		partnerTarget.addPoints(0 - Math.round(amount * target.getRate()));

		return true;
	}

	public Account getAccount() {
		return myAccount;
	}

	public Account getPartnerAccount() {
		return partnerAccount;
	}

	// public void toAlp(double inputBlp) {
	// blp -= inputBlp;
	// alp += Math.round(inputBlp / abRate);
	// }

}
