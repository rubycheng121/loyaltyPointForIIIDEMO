package contract;

import java.util.HashMap;
import java.util.Map;

public class Account {
	private String companyName;
	private Map<String, LoyaltyPoint> loyaltyPoints = new HashMap<String, LoyaltyPoint>();

	public Account(String companyName) {
		super();
		this.companyName = companyName;
		loyaltyPoints.put(companyName, new LoyaltyPoint(companyName, 0, 1));
	}

	public LoyaltyPoint getLoyaltyPoint(String name) {
		return loyaltyPoints.get(name);
	}

	public LoyaltyPoint getLocalLoyaltyPoint() {
		return loyaltyPoints.get(companyName);
	}

	public String getCompanyName() {
		return companyName;
	}

	public void addLoyaltyPoint(String string, LoyaltyPoint loyaltyPoint) {
		loyaltyPoints.put(string, loyaltyPoint);
	}

}
