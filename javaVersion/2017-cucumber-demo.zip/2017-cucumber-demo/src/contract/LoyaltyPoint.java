package contract;

public class LoyaltyPoint {
	private String name;
	private long points;
	private double rate; // 1 local points = "rate" points of "name"

	public LoyaltyPoint(String name, long points, double rate) {
		super();
		this.name = name;
		this.points = points;
		this.rate = rate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPoints() {
		return points;
	}

	public void addPoints(long amount) {
		this.points += amount;
	}

	public void setPoints(long points) {
		this.points = points;
	}

	public double getRate() {
		return rate;
	}

}
