package contract;

public @interface SmartContract { // marker interface

}