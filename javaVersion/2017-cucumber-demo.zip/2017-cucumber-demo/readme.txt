Cucumber-Eclipse update site:
  https://cucumber.io/cucumber-eclipse/update-site
  
Requirement:
  JUnit4
  cucumber-core-1.2.0.jar
  cucumber-java-1.2.0.jar
  cucumber-jvm-deps-1.0.3.jar
  gherkin-2.12.2.jar